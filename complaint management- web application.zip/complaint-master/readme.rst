Complaint Management System 

Web application developed in PHP Codeigniter Framework
developed for Gujarat vidyapith Estate department.

Features:

User side
1. Register a complaint online
2. Track Complaint status
3. View contact details of Enginner
4. Give feedback

Admin side
1. View complaints & Assign to Engineer
2. Update status of complaint
3. Print & Download Reports

Engineer
1. View assigned complaints
2. Update status of complaint

Other features
1. Send E-mail
   1. To Estate department when new complaint registere
   2. To Engineer when complaint assigned to him
   3. To user when complaint status change
